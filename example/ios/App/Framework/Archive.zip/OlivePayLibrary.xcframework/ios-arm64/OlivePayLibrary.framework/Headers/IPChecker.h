//
//  IPChecker.h
//  Axispay
//
//  Created by Atmaram on 09/02/17.
//  Copyright © 2017 bloomsmobility. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IPChecker : NSObject

+ (NSString *)getIP;

@end
